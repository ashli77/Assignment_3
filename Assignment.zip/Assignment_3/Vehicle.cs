﻿// Vehicle Class
public abstract class Vehicle
{
    // Properties
    public string Model { get; set; }
    public string Manufacturer { get; set; }
    public int Year { get; set; }

    // Constructor
    public Vehicle(string model, string manufacturer, int year)
    {
        Model = model;
        Manufacturer = manufacturer;
        Year = year;
    }

    // Abstract method to display details
    public abstract void DisplayDetails();
}
